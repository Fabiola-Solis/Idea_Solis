//// PASOS-A-SEGUIR --> Simulador: ////

/*
1. En esta pantalla se visualizan los productos disponibles en la 'Tienda en línea'(ésta tienda virtual muestra productos,
  permite buscarlos y agregarlos al carrito de compras), conformada por lo siguiente:

  > Filtro de productos.

    - A través de un 'input'/campo y un botón: 'Buscar', se pueden filtrar los productos disponibles; ya sea, incluyendo parte
    o completamente el nombre del producto en cuestión.
    - Además, si se encuentra el producto y el usuario lo quiere comprar, puede agregarlo al 'Carrito de compras' (en botón: 'Añadir a carrito') después de filtrado.
    - Si no existe o no está disponible el producto en 'stock' sale un mensaje que dice: '¡Producto no encontrado!'
    
  > Listados de productos.

    - Son una serie de 'Cards' conformadas por:

      * Una imagen del producto.
      * Título y Precio.
      * Botón: 'Añadir a carrito'.

        >> Al cliquear este botón como su nombre lo dice, se añaden o agregan los productos seleccionados al carrito de compras.
    
  > Carrito de compras.

    - Está sección esta conformada por:

      * Título.
      * Espacio de productos agregados.
      
        >> En esta sección de la página, se ingresan los productos seleccionados; cada vez que se agrega un elemento al carrito,
         se suma su precio al total.

      * Total/monto (ingresado).

      * Botón: 'Vaciar carrito'.

        >> Este botón permite 'vaciar' el carrito de compras y/o productos agregados al mismo (queda en: 0)

      * Botón: 'Comprar productos'.

        >> Si se da clic en el botón antes de ingresar productos al carrito, aparece un mensaje que dice:
        'Debe agregar productos al carrito antes de realizar la compra..'
        >> Si el botón se cliquea después de agregar productos al carrito, se muestra el mensaje:
        '✔️ ¡Su orden ha sido exitosamente realizada! Nos comunicaremos con usted en menos de 24 hrs..',
        Lo anterior, porque este simulador es sobre: 'una Tienda virtual con servicio de Delivery para los clientes del GAM'.
*/



//// SHOP ////


//variables.
const btnSearch = document.querySelector("#btnSearch");
const inputIngreso = document.querySelector("#ingreso");
const contenedor = document.querySelector("#contenedor");


//const carrito = [];

const productos = [
  { id: 1, nombre: "proteína", precio: 1200, img: 'proteina.jpg' },
  { id: 2, nombre: "vitaminas", precio: 1800, img: 'vitaminas.jpg' },
  { id: 3, nombre: "aminoácidos", precio: 2800, img: 'aminoacidos.jpg' },
  { id: 4, nombre: "fibra", precio: 1500, img: 'fibra.jpg' },
  { id: 5, nombre: "hierbas", precio: 1200, img: 'hierbas.jpg' },
  { id: 6, nombre: "colágeno", precio: 1900, img: 'colageno.jpg' }
];

//Funciones de búsqueda.
function buscarProducto(arr, filtro) {
  const encontrado = arr.find((el) => {
    return el.nombre.includes(filtro);
  });
  return encontrado;
}

function filtrarProducto(arr, filtro) {
  const filtrado = arr.filter((el) => {
    return el.nombre.includes(filtro);
  });
  return filtrado;
}

//NUEVAAA
// Función para mostrar productos.
function mostrarProductos(arr) {
  let html = "";
  arr.forEach((el) => {
    html += `<div class="col-12 col-md-6 col-lg-4 mb-3">
                <div class="card">
                  <img src="./img/${el.img}" alt="${el.nombre}">
                  <div class="card-body">
                    <h3 class="card-title">${el.nombre}</h3>
                    <p class="precio" data-precio="${el.precio}">Precio: $${el.precio}</p>
                    <div class="card-action">
                        <button id="${el.id}" class="btn btn-success btn-comprar" data-nombre="${el.nombre}" data-precio="${el.precio}">Añadir al carrito</button>
                    </div>
                  </div>
                </div>
            </div>`;
  });
  contenedor.innerHTML = html;
  asignarEventosCompra(); // Asignar eventos de clic a los botones de compra de los productos mostrados.
}
  

// Evento para mostrar todos los productos cuando se borra el texto del campo de búsqueda.
inputIngreso.addEventListener('input', (e) => {
  if (e.target.value === '') {
    mostrarProductos(productos);
  }
});

// Se muestran todos los productos por defecto.
mostrarProductos(productos);



//// CARRITO ////

/* Se declara una variable total al inicio de tu código y asígnale el valor 0.
Cada vez que se agrega un elemento al carrito, suma su precio a la variable total.
Actualiza el contenido del elemento span con el id "total" con el valor actualizado de la variable total. */

const carrito = document.querySelector("#carrito");
const totalSpan = document.querySelector("#total");
let total = 0;


//Función para asignar eventos de clic a los botones de compra.
function asignarEventosCompra() {
  // Recorre los botones de compra y agregar un escuchador de eventos de clic.
  document.querySelectorAll(".btn-comprar").forEach((btn) => {
    btn.addEventListener("click", () => {
      // Obtiene el nombre y precio del producto seleccionado.
      const nombre = btn.getAttribute("data-nombre");
      const precio = btn.getAttribute("data-precio");

      // Crea un nuevo elemento li con el nombre y precio del producto seleccionado.
      const itemCarrito = document.createElement("li");
      itemCarrito.innerHTML = `${nombre} - $${precio}`;

      // Agrega el elemento li al carrito.
      carrito.appendChild(itemCarrito);

      // Suma el precio del producto al total.
      total += parseFloat(precio);

      // Actualizar el contenido del elemento span con el total.
      totalSpan.innerHTML = total.toFixed(2);
    });
  });
}


// Función para vaciar el carrito.
function vaciarCarrito() {
  // Eliminar todos los elementos del carrito.
  while (carrito.firstChild) {
    carrito.removeChild(carrito.firstChild);
  }

  // Actualizar el total a 0.
  total = 0;
  totalSpan.innerHTML = total.toFixed(2);
}


// Filtro
// Evento para mostrar todos los productos cuando se borra el texto del campo de búsqueda.
inputIngreso.addEventListener('input', (e) => {
  if (e.target.value === '') {
    mostrarProductos(productos);
  }
});

// Se muestran todos los productos por defecto.
mostrarProductos(productos);


// Filtro
btnSearch.addEventListener(`click`, () => {
  const filtro = inputIngreso.value.toLowerCase();
  const filtrado = filtrarProducto(productos, filtro);

  if (filtrado.length === 0) {
    contenedor.innerHTML = `<p class="alert-wn">¡Producto no encontrado!</p>`;
  } else {
    mostrarProductos(filtrado); // Mostrar los productos filtrados.
  }
});


// Escuchador de eventos para el botón "Vaciar".
const botonVaciar = document.querySelector("#boton-vaciar");
botonVaciar.addEventListener("click", vaciarCarrito);

// Mensaje de compra realizada.
document.getElementById('comprarProductos').addEventListener('click', function() {

  // Verifica si el carrito contiene elementos li.
  if (document.querySelectorAll('#carrito li').length > 0) {
    // Muestra el mensaje de éxito.
    document.getElementById('mensajeCompra').innerHTML = '✔️  ¡Su orden ha sido exitosamente realizada! Nos comunicaremos con usted en menos de 24 hrs..';
  } else {
    // Muestra un mensaje de error.
    document.getElementById('mensajeCompra').innerHTML = 'Debe agregar productos al carrito antes de realizar la compra..';
  }
});

//////////////////////


