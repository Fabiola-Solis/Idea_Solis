
//// PASOS-A-SEGUIR --> Simulador: ////

/*
1. Al ingresar a esta pantalla se abre un 'Modal' para 'Inciar sesión', con los espacios y/o 'inputs' para incluir:

> Usuario
> Contraseña
> Botón: 'Inciar sesión'
> Botón: 'Registrarse'

  - Si el usuario ya tiene 'usuario/contraseña; registrados, se ingresan los datos en 'inputs' correspondientes
  y se cliquea el botón: 'Inciar sesión'
  - Pero si todavía no se cuenta con un 'usuario/contraseña, se hace clic en el Botón: 'Registrarse'. Inmediatamente,
  se cierra el 'Modal' y se visualiza la página/form, para 'Registrarse'.

2. El fomulario para 'Registrarse' incluye varios espacios y/o 'inputs':

> Nombre
> Usuario
> Email
> Contraseña

  - Si se ingresan todos los datos/inputs para 'Registrarse', y luego se hace clic en el botón: 'Registarse,
  los datos ingresados (nuevo usuario) se almacena/guarda en el 'Local Storage'.
  - Seguidamente, si se da clic en el botón: 'Iniciar sesión', se abre de nuevo el 'Modal' (se recuperan los datos
  del nuevo usuario) se ingresa el 'nuevo usuario' en los campos/inputs:

    * Usuario
    * Contraseña
    
      - Luego, cliquea el botón: 'Iniciar Sesión' (Login) y se ingresa a la página: 'Tienda en línea/Productos' (shop.html), con el nuevo usuario.
*/



//// REGISTER | LOGIN ////


//Modal

 // Función para mostrar el modal de inicio de sesión.
 function showLoginModal() {
  // Obtener el botón de abrir el modal de inicio de sesión.
  const loginModalButton = document.getElementById('login-modal-button');
  // Hacer clic en el botón para abrir el modal de inicio de sesión.
  loginModalButton.click();
}
// Llamar a la función de mostrar el modal de inicio de sesión al cargar la página.
window.onload = function() {
  showLoginModal();
}


// Se define la clase constructora de usuarios.
class User {
    constructor(name, username, email, password) {
      this.name = name;
      this.username = username;
      this.email = email;
      this.password = password;
    }
  }
  

// Referencias a los elementos del formulario de registro.
  const formRegister = document.getElementById("formRegister");
  const nombreInput = document.getElementById("nombreInput");
  const userRegInput = document.getElementById("userRegInput");
  const emailInput = document.getElementById("emailInput");
  const passRegInput = document.getElementById("passRegInput");
  

// Agregar evento de escucha al botón de registro.
  document.getElementById("registrar").addEventListener("click", function (event) {
    event.preventDefault(); // Prevenimos que el formulario se envíe automáticamente.

    // Creamos un nuevo objeto de usuario.
    const newUser = new User(
      nombreInput.value,
      userRegInput.value,
      emailInput.value,
      passRegInput.value
    );
    
    // Guardamos el usuario en local storage como JSON.
    localStorage.setItem("currentUser", JSON.stringify(newUser));
    
    // Imprimimos el usuario guardado en la consola.
    console.log(JSON.parse(localStorage.getItem("currentUser")));

    // Limpiamos los campos del formulario de registro.
    formRegister.reset();
  });
  


// Referencias a los elementos del formulario de inicio de sesión.
  const loginForm = document.getElementById("ingresar");
  const loginUsername = document.getElementById("login-username");
  const loginPassword = document.getElementById("login-password");
  

// Se agrega el evento de escucha al botón de ingresar.
  document.querySelector("#login-modal .btn-success").addEventListener("click", function () {
    // Se obtiene el usuario guardado en local storage.
    const storedUser = JSON.parse(localStorage.getItem("currentUser"));
    
    // Se obtienen los valores de usuario y contraseña ingresados en el formulario.
    const enteredUsername = loginUsername.value;
    const enteredPassword = loginPassword.value;

    // Selecciona el elemento <p> para mostrar el mensaje de error
    const errorMessage = document.getElementById("errorMessage");
    
    // Se verifica si los datos son correctos.
    if (storedUser && enteredUsername === storedUser.username && enteredPassword === storedUser.password) {
      // Redireccionamos a la página 'shop.html'
      window.location.href = "shop.html";
    } else {
      // Asigna el mensaje de error al contenido del elemento <p>
      errorMessage.textContent = "¡Usuario no encontrado! Debes dar click en 'Registrarse'.";
    }
    
    // Limpiamos los campos del formulario de inicio de sesión
    loginForm.reset();
  });


//Función de cerrar el Modal al hacer clic en el enlace de registro.
function cerrarModal() {
    $('#login-modal').modal('hide');
  }
  